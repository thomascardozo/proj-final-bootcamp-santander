package com.dio.livecoding.crud.salasdereuniao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalasdereuniaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
